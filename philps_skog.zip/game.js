// ============================================
// SKOGENS ÖVERLEVARE — GAME ENGINE
// Complete rewrite with tent, fire, warmth, cooking, levels
// ============================================

const canvas = document.getElementById('game-canvas');
const renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
scene.fog = new THREE.FogExp2('#0d200d', 0.0015);
scene.background = new THREE.Color('#0d200d');

const camera3d = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 2000);

// Lighting
const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
scene.add(ambientLight);

const fireLight = new THREE.PointLight(0xffaa00, 0, 400);
fireLight.castShadow = true;
fireLight.position.y = 20;
scene.add(fireLight);

// Setup Object pools & materials
const gameMeshes = [];
const materials = {
    grass: new THREE.MeshLambertMaterial({ color: '#2d5a2d' }),
    dirt: new THREE.MeshLambertMaterial({ color: '#5a4830' }),
    water: new THREE.MeshStandardMaterial({ color: '#1a4a5a', transparent: true, opacity: 0.8, roughness: 0.1, metalness: 0.4 }),
    treeTrunkPine: new THREE.MeshLambertMaterial({ color: '#3a2a1a' }),
    treeTrunkBirch: new THREE.MeshLambertMaterial({ color: '#d4cfc0' }),
    treeLeavesPine: new THREE.MeshLambertMaterial({ color: '#1a4a20' }),
    treeLeavesOak: new THREE.MeshLambertMaterial({ color: '#2a5a25' }),
    rock: new THREE.MeshLambertMaterial({ color: '#645f55' }),
    bush: new THREE.MeshLambertMaterial({ color: '#2a5a30' }),
    berry: new THREE.MeshLambertMaterial({ color: '#4444cc' }),
    tent: new THREE.MeshLambertMaterial({ color: '#5a4a35' }),
    fireStone: new THREE.MeshLambertMaterial({ color: '#5a5550' }),
    player: new THREE.MeshLambertMaterial({ color: '#44aaff' }),
    blood: new THREE.MeshBasicMaterial({ color: '#cc2222' }),
    stick: new THREE.MeshLambertMaterial({ color: '#5a3a1a' }),
    stoneItem: new THREE.MeshLambertMaterial({ color: '#999999' }),
    rawmeat: new THREE.MeshLambertMaterial({ color: '#cc5555' }),
    chest: new THREE.MeshLambertMaterial({ color: '#8b6914' })
};
const geometries = {
    cylinder: new THREE.CylinderGeometry(1, 1, 1, 8),
    cone: new THREE.ConeGeometry(1, 1, 8),
    sphere: new THREE.SphereGeometry(1, 12, 12),
    box: new THREE.BoxGeometry(1, 1, 1),
    dodecahedron: new THREE.DodecahedronGeometry(1)
};


// --- CONSTANTS ---
const TILE = 40;
const WORLD_W = 120, WORLD_H = 120;
const DAY_LENGTH = 180;
const MAX_LEVEL = 10;
const LEVEL_TIME = 45; // seconds per level

const ANIMAL_TYPES = {
    wolf: { emoji: '🐺', hp: 40, speed: 1.8, damage: 12, detect: 220, attack: 30, pack: true, color: '#555' },
    bear: { emoji: '🐻', hp: 100, speed: 1.0, damage: 25, detect: 180, attack: 35, territorial: true, color: '#6b4226' },
    snake: { emoji: '🐍', hp: 15, speed: 1.3, damage: 18, detect: 100, attack: 25, hidden: true, color: '#4a6b2a' },
    boar: { emoji: '🐗', hp: 50, speed: 1.5, damage: 15, detect: 160, attack: 30, charges: true, color: '#5a4030' },
    deer: { emoji: '🦌', hp: 20, speed: 2.2, damage: 0, detect: 250, attack: 0, flees: true, color: '#8b6914' },
    rabbit: { emoji: '🐇', hp: 8, speed: 2.5, damage: 0, detect: 200, attack: 0, flees: true, color: '#b0a090' }
};
const ITEMS = {
    stick: { emoji: '🪵', name: 'Ved', stack: 10 },
    stone: { emoji: '🪨', name: 'Sten', stack: 10 },
    rawmeat: { emoji: '🥩', name: 'Rått kött', stack: 10 },
    cookedmeat: { emoji: '🍖', name: 'Lagat kött', stack: 5, food: 40, heal: 15 },
    berry: { emoji: '🫐', name: 'Bär', stack: 10, food: 12, heal: 2 },
    mushroom: { emoji: '🍄', name: 'Svamp', stack: 8, food: 18, heal: 5 },
    spear: { emoji: '🔱', name: 'Spjut', stack: 1, weapon: true, damage: 20 },
    axe: { emoji: '🪓', name: 'Yxa', stack: 1, weapon: true, damage: 15 },
    sword: { emoji: '🗡️', name: 'Svärd', stack: 1, weapon: true, damage: 30 },
    bandage: { emoji: '🩹', name: 'Bandage', stack: 5, heal: 25 },
    water: { emoji: '💧', name: 'Vatten', stack: 5, thirst: 35 },
    coal: { emoji: 'coal', name: 'Kol', stack: 10, fireFuel: 25 },
    oil: { emoji: '🛢️', name: 'Olja', stack: 1, fireFuel: 80 }
};

// Chest loot table: [item, count, weight]
const CHEST_LOOT = [
    ['stick', 3, 25], ['stone', 2, 20], ['berry', 4, 15],
    ['mushroom', 2, 12], ['bandage', 1, 10], ['axe', 1, 6],
    ['cookedmeat', 2, 5], ['coal', 3, 5], ['oil', 1, 2]
];

function rollChestLoot() {
    const loot = [];
    const numItems = randInt(1, 3);
    for (let i = 0; i < numItems; i++) {
        const totalWeight = CHEST_LOOT.reduce((sum, item) => sum + item[2], 0);
        let roll = rand(0, totalWeight);
        for (const item of CHEST_LOOT) {
            roll -= item[2];
            if (roll <= 0) {
                loot.push([item[0], randInt(1, item[1])]);
                break;
            }
        }
    }
    return loot;
}

// --- STATE ---
let state = 'menu';
let highScore = parseInt(localStorage.getItem('forestHS') || '0');
let keys = {}, camera = { x: 0, y: 0 };
let gameTime = 0, dayTime = 0.25, survivalTime = 0, kills = 0, level = 1;
let messages = [];
let world = { trees: [], bushes: [], rocks: [], waters: [], items: [], chests: [], camp: null };
let animals = [], particles = [], player = null;
let lastSpawnLevel = 0;

// --- RESIZE ---
function resize() { canvas.width = window.innerWidth; canvas.height = window.innerHeight; }
window.addEventListener('resize', resize);
resize();

// --- INPUT ---
window.addEventListener('keydown', e => {
    keys[e.code] = true;
    keys[e.key.toLowerCase()] = true; // For special characters like 'ö'
    if (e.code === 'Space') e.preventDefault();
});
window.addEventListener('keyup', e => {
    keys[e.code] = false;
    keys[e.key.toLowerCase()] = false;
});
window.addEventListener('mousedown', e => {
    if (e.button === 0 && state === 'playing') {
        keys['Space'] = true; // Map left click to attack (Space)
    }
});
window.addEventListener('mouseup', e => {
    if (e.button === 0) {
        keys['Space'] = false;
    }
});

// --- UI ---
const $menu = document.getElementById('main-menu');
const $hud = document.getElementById('hud');
const $over = document.getElementById('game-over');
const $howto = document.getElementById('howto-panel');
document.getElementById('high-score-display').textContent = `Rekord: ${highScore}s`;
document.getElementById('btn-start').onclick = startGame;
document.getElementById('btn-howto').onclick = () => $howto.classList.toggle('hidden');
document.getElementById('btn-restart').onclick = startGame;
document.getElementById('btn-menu').onclick = () => { $over.classList.add('hidden'); $menu.classList.remove('hidden'); state = 'menu'; };
document.getElementById('btn-share').onclick = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(() => {
        addMsg('🔗 Länk kopierad till urklipp! Dela med dina vänner!');
    });
};

// --- UTILS ---
function dist(a, b) { return Math.hypot(a.x - b.x, a.y - b.y); }
function rand(a, b) { return a + Math.random() * (b - a); }
function randInt(a, b) { return Math.floor(rand(a, b + 1)); }
function lerp(a, b, t) { return a + (b - a) * t; }
function clamp(v, mn, mx) { return Math.max(mn, Math.min(mx, v)); }
function angle(a, b) { return Math.atan2(b.y - a.y, b.x - a.x); }
function addMsg(txt) { messages.push({ txt, t: 4 }); if (messages.length > 4) messages.shift(); }

// --- NOISE ---
function sn(x, y) { const n = Math.sin(x * 127.1 + y * 311.7) * 43758.5453; return n - Math.floor(n); }
function smn(x, y) {
    const ix = Math.floor(x), iy = Math.floor(y), fx = x - ix, fy = y - iy;
    const sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
    return lerp(lerp(sn(ix, iy), sn(ix + 1, iy), sx), lerp(sn(ix, iy + 1), sn(ix + 1, iy + 1), sx), sy);
}
function fbm(x, y) { return smn(x * 0.02, y * 0.02) * 0.5 + smn(x * 0.05, y * 0.05) * 0.3 + smn(x * 0.1, y * 0.1) * 0.2; }

// --- WORLD GEN ---
function generateWorld() {
    world = { trees: [], bushes: [], rocks: [], waters: [], items: [], chests: [], camp: null };
    animals = []; particles = [];
    const cx = WORLD_W * TILE / 2, cy = WORLD_H * TILE / 2;

    // Camp with broken tent and firepit
    world.camp = {
        x: cx, y: cy,
        fire: { x: cx + 30, y: cy + 20, lit: true, fuel: 100, maxFuel: 100 },
        tent: { x: cx - 40, y: cy - 20 }
    };

    // Water
    for (let i = 0; i < 6; i++) {
        const wx = rand(400, WORLD_W * TILE - 400), wy = rand(400, WORLD_H * TILE - 400);
        if (dist({ x: wx, y: wy }, { x: cx, y: cy }) < 250) continue;
        world.waters.push({ x: wx, y: wy, r: rand(60, 130) });
    }

    // Trees
    for (let i = 0; i < 900; i++) {
        const x = rand(50, WORLD_W * TILE - 50), y = rand(50, WORLD_H * TILE - 50);
        if (world.waters.some(w => dist({ x, y }, w) < w.r + 30)) continue;
        if (dist({ x, y }, { x: cx, y: cy }) < 100) continue;
        const h = rand(0.6, 1.0);
        const type = Math.random() < 0.3 ? 'pine' : Math.random() < 0.5 ? 'oak' : 'birch';
        world.trees.push({ x, y, h, type, r: 12 + h * 10, sway: rand(0, 6.28), swaySpd: rand(0.3, 0.8), hp: 3 });
    }

    // Bushes
    for (let i = 0; i < 200; i++) {
        const x = rand(50, WORLD_W * TILE - 50), y = rand(50, WORLD_H * TILE - 50);
        if (world.waters.some(w => dist({ x, y }, w) < w.r + 20)) continue;
        world.bushes.push({ x, y, r: rand(8, 16), hasBerry: Math.random() < 0.35, picked: false });
    }

    // Rocks
    for (let i = 0; i < 120; i++) {
        const x = rand(50, WORLD_W * TILE - 50), y = rand(50, WORLD_H * TILE - 50);
        world.rocks.push({ x, y, r: rand(8, 20), shade: rand(0.3, 0.7) });
    }

    // Scattered sticks and stones
    for (let i = 0; i < 50; i++) {
        const x = rand(100, WORLD_W * TILE - 100), y = rand(100, WORLD_H * TILE - 100);
        world.items.push({ x, y, type: Math.random() < 0.6 ? 'stick' : 'stone', bobT: rand(0, 6.28) });
    }

    // Old chests scattered around
    for (let i = 0; i < 15; i++) {
        const x = rand(300, WORLD_W * TILE - 300), y = rand(300, WORLD_H * TILE - 300);
        if (dist({ x, y }, { x: cx, y: cy }) < 200) continue;
        world.chests.push({ x, y, opened: false, loot: rollChestLoot() });
    }

    // The starting chest (added AFTER so it doesn't get messed up)
    world.chests.push({
        x: cx - 55, y: cy - 20, opened: false, loot: [['axe', 1], ['sword', 1], ['rawmeat', 10]]
    });

    spawnAnimalsForLevel(1);
}

function spawnAnimalsForLevel(lvl) {
    const cx = WORLD_W * TILE / 2, cy = WORLD_H * TILE / 2;
    const wolfPacks = Math.min(2 + lvl, 8);
    const bears = Math.min(1 + Math.floor(lvl / 2), 6);
    const snakes = Math.min(4 + lvl * 2, 20);
    const boars = Math.min(2 + lvl, 10);

    for (let p = 0; p < wolfPacks; p++) {
        const px = rand(500, WORLD_W * TILE - 500), py = rand(500, WORLD_H * TILE - 500);
        if (dist({ x: px, y: py }, { x: cx, y: cy }) < 350) continue;
        for (let i = 0; i < randInt(2, 4); i++) animals.push(mkAnimal('wolf', px + rand(-60, 60), py + rand(-60, 60), p));
    }
    for (let i = 0; i < bears; i++) {
        const x = rand(400, WORLD_W * TILE - 400), y = rand(400, WORLD_H * TILE - 400);
        if (dist({ x, y }, { x: cx, y: cy }) < 500) continue;
        animals.push(mkAnimal('bear', x, y));
    }
    for (let i = 0; i < snakes; i++) {
        const x = rand(200, WORLD_W * TILE - 200), y = rand(200, WORLD_H * TILE - 200);
        if (dist({ x, y }, { x: cx, y: cy }) < 200) continue;
        animals.push(mkAnimal('snake', x, y));
    }
    for (let i = 0; i < boars; i++) {
        const x = rand(300, WORLD_W * TILE - 300), y = rand(300, WORLD_H * TILE - 300);
        if (dist({ x, y }, { x: cx, y: cy }) < 350) continue;
        animals.push(mkAnimal('boar', x, y));
    }
    // Passive
    for (let i = 0; i < 8; i++) animals.push(mkAnimal('deer', rand(200, WORLD_W * TILE - 200), rand(200, WORLD_H * TILE - 200)));
    for (let i = 0; i < 10; i++) animals.push(mkAnimal('rabbit', rand(200, WORLD_W * TILE - 200), rand(200, WORLD_H * TILE - 200)));
}

function mkAnimal(type, x, y, packId) {
    const t = ANIMAL_TYPES[type];
    return {
        type, x, y, vx: 0, vy: 0, hp: t.hp, maxHp: t.hp, dir: rand(0, 6.28), state: 'idle',
        stateTimer: rand(1, 5), attackCd: 0, packId: packId ?? -1, homeX: x, homeY: y,
        hidden: t.hidden || false, revealed: false, stunTimer: 0, hitFlash: 0, animT: rand(0, 6.28)
    };
}

function createPlayer() {
    const cx = WORLD_W * TILE / 2, cy = WORLD_H * TILE / 2;
    return {
        x: cx, y: cy, vx: 0, vy: 0, dir: 0, hp: 100, maxHp: 100,
        hunger: 80, thirst: 80, stamina: 100, warmth: 70,
        speed: 2.5, sprinting: false,
        inventory: [{ type: 'stick', count: 3 }, null, null, null, null, null],
        selectedSlot: 0, attackCd: 0, attackAnim: 0, invincible: 0, hitFlash: 0,
        weaponDamage: 8, deathCause: ''
    };
}

function startGame() {
    $menu.classList.add('hidden'); $over.classList.add('hidden'); $hud.classList.remove('hidden');
    player = createPlayer(); generateWorld();
    gameTime = 0; survivalTime = 0; kills = 0; level = 1; lastSpawnLevel = 1;
    dayTime = 0.25; messages = []; state = 'playing';

    // Clear old 3D meshes
    gameMeshes.forEach(m => scene.remove(m));
    gameMeshes.length = 0;

    // Create Terrain
    const terrainGeo = new THREE.PlaneGeometry(WORLD_W * TILE, WORLD_H * TILE, 32, 32);
    const terrain = new THREE.Mesh(terrainGeo, materials.grass);
    terrain.rotation.x = -Math.PI / 2;
    terrain.position.set(WORLD_W * TILE / 2, -0.1, WORLD_H * TILE / 2);
    terrain.receiveShadow = true;
    scene.add(terrain);
    gameMeshes.push(terrain);

    // Create Water
    for (const w of world.waters) {
        const waterDrop = new THREE.Mesh(new THREE.CylinderGeometry(w.r, w.r, 2, 32), materials.water);
        waterDrop.position.set(w.x, 0.5, w.y);
        waterDrop.receiveShadow = true;
        scene.add(waterDrop);
        gameMeshes.push(waterDrop);
    }

    addMsg('🌲 Du vaknar vid ett trasigt tält. Elden brinner svagt...');
    addMsg('🪵 Samla ved snabbt! Tryck E för att plocka upp.');
}

// --- INVENTORY ---
function addItem(type, count) {
    count = count || 1; const info = ITEMS[type];
    for (let s of player.inventory) { if (s && s.type === type && s.count < info.stack) { const a = Math.min(count, info.stack - s.count); s.count += a; count -= a; if (count <= 0) return true; } }
    for (let i = 0; i < player.inventory.length; i++) { if (!player.inventory[i]) { player.inventory[i] = { type, count: Math.min(count, info.stack) }; return true; } }
    return false;
}
function hasItem(t, c) { c = c || 1; let n = 0; for (let s of player.inventory) if (s && s.type === t) n += s.count; return n >= c; }
function removeItem(t, c) { c = c || 1; for (let s of player.inventory) { if (s && s.type === t) { const r = Math.min(c, s.count); s.count -= r; c -= r; if (s.count <= 0) { const i = player.inventory.indexOf(s); player.inventory[i] = null; } if (c <= 0) return true; } } return c <= 0; }
function getSelItem() { const s = player.inventory[player.selectedSlot]; return s ? ITEMS[s.type] : null; }

// --- UPDATE ---
let lastTime = 0;
function update(dt) {
    if (state !== 'playing') return;
    gameTime += dt; survivalTime += dt;
    dayTime = (dayTime + dt / DAY_LENGTH) % 1.0;

    // Level progression
    const newLevel = Math.min(MAX_LEVEL, Math.floor(survivalTime / LEVEL_TIME) + 1);
    if (newLevel > level) {
        level = newLevel;
        addMsg(`📈 Nivå ${level}/${MAX_LEVEL}! Fler djur dyker upp...`);
        // Spawn more animals
        if (level > lastSpawnLevel) { spawnAnimalsForLevel(level); lastSpawnLevel = level; }
    }

    updatePlayer(dt);
    updateAnimals(dt);
    updateFire(dt);
    updateParticles(dt);
    updateMessages(dt);
    updateHUD();
    camera.x = lerp(camera.x, player.x - canvas.width / 2, 0.1);
    camera.y = lerp(camera.y, player.y - canvas.height / 2, 0.1);
}

function isNight() { return dayTime > 0.75 || dayTime < 0.2; }
function getDarkness() {
    if (dayTime >= 0.25 && dayTime <= 0.7) return 0;
    if (dayTime > 0.7 && dayTime <= 0.8) return (dayTime - 0.7) / 0.1;
    if (dayTime > 0.8 || dayTime < 0.15) return 1;
    if (dayTime >= 0.15 && dayTime < 0.25) return 1 - (dayTime - 0.15) / 0.1;
    return 0;
}

function updatePlayer(dt) {
    const p = player, fire = world.camp.fire;
    let mx = 0, my = 0;
    if (keys['KeyW'] || keys['ArrowUp']) my = -1;
    if (keys['KeyS'] || keys['ArrowDown']) my = 1;
    if (keys['KeyA'] || keys['ArrowLeft']) mx = -1;
    if (keys['KeyD'] || keys['ArrowRight']) mx = 1;
    if (mx || my) { const l = Math.hypot(mx, my); mx /= l; my /= l; p.dir = Math.atan2(my, mx); }

    p.sprinting = keys['ShiftLeft'] || keys['ShiftRight'];
    let spd = p.speed;
    if (p.sprinting && p.stamina > 0) { spd *= 1.7; p.stamina -= 20 * dt; } else { p.stamina = Math.min(100, p.stamina + 15 * dt); }
    p.vx = mx * spd; p.vy = my * spd;

    // Collision
    let nx = p.x + p.vx, ny = p.y + p.vy;
    for (const t of world.trees) { if (dist({ x: nx, y: ny }, t) < t.r + 8) { nx = p.x; ny = p.y; break; } }
    nx = clamp(nx, 20, WORLD_W * TILE - 20); ny = clamp(ny, 20, WORLD_H * TILE - 20);
    p.x = nx; p.y = ny;

    // Survival - 15 minutes (900s) to drain from 100 to 0 = 0.111 per second
    p.hunger -= (100 / 900) * dt;
    // Thirst removed
    // p.thirst -= 3.0*dt; 
    // if(world.waters.some(w=>dist(p,w)<w.r)) p.thirst=Math.min(100,p.thirst+10*dt);

    // Warmth — CRITICAL: needs fire
    const nearFire = fire.lit && dist(p, fire) < 120;
    if (nearFire) { p.warmth = Math.min(100, p.warmth + 15 * dt); }
    else {
        // Drain 100 warmth in 15 mins (900s) = 0.111/s
        const coldRate = isNight() ? (100 / 450) : (100 / 900); // Twice as fast at night
        p.warmth -= coldRate * dt;
    }
    p.warmth = clamp(p.warmth, 0, 100);

    // Damage
    if (p.hunger <= 0) { p.hp -= 8 * dt; p.hunger = 0; }
    // Thirst death removed
    // if(p.thirst<=0) { p.hp-=6*dt; p.thirst=0; }
    if (p.warmth <= 15) { p.hp -= (15 - p.warmth) * 0.5 * dt; } // Cold damage scales
    if (p.warmth <= 0) p.hp -= 10 * dt; // Freezing!

    // Timers
    if (p.attackCd > 0) p.attackCd -= dt;
    if (p.attackAnim > 0) p.attackAnim -= dt;
    if (p.invincible > 0) p.invincible -= dt;
    if (p.hitFlash > 0) p.hitFlash -= dt;

    // Attack
    if (keys['Space'] && p.attackCd <= 0) {
        p.attackCd = 0.5; p.attackAnim = 0.3;
        const sel = getSelItem();
        const dmg = (sel && sel.weapon) ? sel.damage : p.weaponDamage;
        for (const a of animals) {
            if (dist(p, a) < 45) {
                const aDir = angle(p, a);
                const diff = Math.abs(((aDir - p.dir + Math.PI) % (2 * Math.PI)) - Math.PI);
                if (diff < 1.2) {
                    a.hp -= dmg; a.hitFlash = 0.2; a.stunTimer = 0.3; a.alerted = true; a.state = 'chase';
                    for (let i = 0; i < 5; i++) particles.push({ x: a.x, y: a.y, vx: rand(-2, 2), vy: rand(-2, 2), life: 0.5, color: '#8b0000', r: 3 });
                    if (ANIMAL_TYPES[a.type].pack) animals.filter(b => b.packId === a.packId && b !== a).forEach(b => { b.alerted = true; b.state = 'chase'; });
                }
            }
        }
        // Attack/Chop Trees
        for (let i = world.trees.length - 1; i >= 0; i--) {
            const t = world.trees[i];
            if (dist(p, t) < t.r + 40) {
                const aDir = angle(p, t);
                const diff = Math.abs(((aDir - p.dir + Math.PI) % (2 * Math.PI)) - Math.PI);
                if (diff < 1.2) {
                    t.hp--;
                    // Particles for wood chips
                    for (let j = 0; j < 5; j++) particles.push({ x: t.x, y: t.y, vx: rand(-2, 2), vy: rand(-2, 2), life: 0.4, color: t.type === 'birch' ? '#d4cfc0' : '#3a2a1a', r: rand(2, 4) });

                    if (t.hp <= 0) {
                        // Drop sticks
                        const count = randInt(2, 4);
                        for (let j = 0; j < count; j++) {
                            world.items.push({ x: t.x + rand(-15, 15), y: t.y + rand(-15, 15), type: 'stick', bobT: rand(0, 6.28) });
                        }
                        addMsg('🪓 Fällde ett träd!');

                        // Remove from 3D scene
                        const mesh = meshes.get(t);
                        if (mesh) {
                            scene.remove(mesh);
                            meshes.delete(t);
                        }
                        world.trees.splice(i, 1);
                    }
                }
            }
        }
    }

    // Cooking with 'L'
    if (keys['KeyL'] && dist(p, fire) < 60 && fire.lit && hasItem('rawmeat')) {
        if (p.vx === 0 && p.vy === 0) {
            p.cookingTimer = (p.cookingTimer || 0) + dt;
            if (p.cookingTimer >= 10) {
                removeItem('rawmeat', 1);
                addItem('cookedmeat', 1);
                addMsg('🍖 Lagade ett kött vid elden!');
                p.cookingTimer = 0;
            } else {
                const remaining = Math.ceil(10 - p.cookingTimer);
                if (p.lastCookMsg !== remaining) {
                    addMsg(`⏳ Lagar mat... ${remaining}s kvar`);
                    p.lastCookMsg = remaining;
                }
            }
        } else {
            p.cookingTimer = 0;
            if (Math.random() < 0.05) addMsg('⚠️ Stå helt stilla för att laga mat!');
        }
    } else {
        p.cookingTimer = 0;
        p.lastCookMsg = 0;
    }

    // Open chest with Ö
    if (keys['ö']) {
        keys['ö'] = false;
        for (const ch of world.chests) {
            if (!ch.opened && dist(p, ch) < 50) {
                ch.opened = true;
                addMsg('📦 Öppnade kistan!');
                for (const [type, count] of ch.loot) {
                    addItem(type, count);
                    addMsg(`  ${ITEMS[type].emoji} ${ITEMS[type].name} x${count}`);
                }
                break;
            }
        }
    }

    // Pickup (0)
    if (keys['Digit0']) {
        keys['Digit0'] = false;
        // Fire interaction — add wood
        if (dist(p, fire) < 80) {
            if (hasItem('coal') || hasItem('oil')) {
                // Use coal or oil for fire
                if (hasItem('oil')) {
                    removeItem('oil', 1);
                    fire.fuel = Math.min(fire.maxFuel, fire.fuel + 80);
                    if (!fire.lit) fire.lit = true;
                    addMsg('🛢️ Hällde olja på elden! (+80%)');
                } else {
                    removeItem('coal', 1);
                    fire.fuel = Math.min(fire.maxFuel, fire.fuel + 25);
                    if (!fire.lit) fire.lit = true;
                    addMsg('ite Lade kol i elden (+25%)');
                }
            } else if (hasItem('stick')) {
                const amt = Math.min(3, player.inventory.find(s => s && s.type === 'stick')?.count || 0);
                removeItem('stick', amt);
                fire.fuel = Math.min(fire.maxFuel, fire.fuel + amt * 15);
                if (!fire.lit) { fire.lit = true; addMsg('🔥 Tände elden igen!'); }
                else addMsg(`🪵 La ${amt} ved i elden (+${amt * 15}%)`);
            }
        } else {
            let acted = false;
            if (!acted) {
                // Ground items
                for (let i = world.items.length - 1; i >= 0; i--) {
                    const it = world.items[i];
                    if (dist(p, it) < 35) { if (addItem(it.type)) { addMsg(`${ITEMS[it.type].emoji} ${ITEMS[it.type].name}`); world.items.splice(i, 1); acted = true; } break; }
                }
            }
            if (!acted) {
                // Bushes
                for (const b of world.bushes) {
                    if (!b.picked && b.hasBerry && dist(p, b) < 30) { b.picked = true; addItem('berry', randInt(1, 3)); addMsg('🫐 Plockade bär'); acted = true; break; }
                }
            }
            if (!acted) {
                // Water
                for (const w of world.waters) {
                    if (dist(p, w) < w.r + 20) { addItem('water', 1); addMsg('💧 Fyllde på vatten'); break; }
                }
            }
        }
    }

    // Use items (1-6)
    for (let i = 0; i < 6; i++) {
        if (keys[`Digit${i + 1}`]) {
            keys[`Digit${i + 1}`] = false; p.selectedSlot = i;
            const s = p.inventory[i]; if (!s) continue;
            const info = ITEMS[s.type];
            let used = false;

            if (info.food) { p.hunger = Math.min(100, p.hunger + info.food); used = true; }
            if (info.heal) { p.hp = Math.min(p.maxHp, p.hp + info.heal); used = true; }
            if (info.thirst) { p.thirst = Math.min(100, p.thirst + info.thirst); used = true; }

            if (used) {
                const itemEmoji = info.emoji;
                removeItem(s.type, 1);
                if (info.food) addMsg(`Åt ${itemEmoji}${info.heal ? ' (HP+)' : ''}`);
                else if (info.thirst) addMsg(`Drack ${itemEmoji}`);
                else if (info.heal) addMsg(`${itemEmoji} HP +${info.heal}`);
            }
        }
    }

    // Crafting (C)
    if (keys['KeyC']) {
        keys['KeyC'] = false;
        if (hasItem('stick', 3) && hasItem('stone', 2)) { removeItem('stick', 3); removeItem('stone', 2); addItem('spear'); addMsg('🔱 Tillverkade spjut!'); }
        else if (hasItem('stick', 2) && hasItem('stone', 1)) { removeItem('stick', 2); removeItem('stone', 1); addItem('axe'); addMsg('🪓 Tillverkade yxa!'); }
        else if (hasItem('berry', 3)) { removeItem('berry', 3); addItem('bandage'); addMsg('🩹 Tillverkade bandage!'); }
    }

    // Death
    if (p.hp <= 0) {
        if (!p.deathCause) {
            if (p.warmth <= 0) p.deathCause = 'Frös ihjäl';
            else if (p.hunger <= 0) p.deathCause = 'Svalt ihjäl';
            else p.deathCause = 'Dog av skador';
        }
        gameOver(p.deathCause);
    }
}

function updateFire(dt) {
    const fire = world.camp.fire;
    if (fire.lit) {
        // Fire lasts 10 minutes (600s) on all levels
        fire.fuel -= (100 / 600) * dt;
        if (fire.fuel <= 0) { fire.lit = false; fire.fuel = 0; addMsg('❄️ Elden slocknade! Du fryser!'); }
        // Particles
        if (Math.random() < 0.4) particles.push({ x: fire.x + rand(-8, 8), y: fire.y + rand(-5, 0), vx: rand(-0.5, 0.5), vy: rand(-2, -0.5), life: rand(0.5, 1.2), color: Math.random() < 0.5 ? '#ff6600' : '#ffaa00', r: rand(2, 5) });
    }
    // Respawn sticks periodically
    if (Math.random() < 0.005 * dt) {
        const x = rand(200, WORLD_W * TILE - 200), y = rand(200, WORLD_H * TILE - 200);
        world.items.push({ x, y, type: 'stick', bobT: rand(0, 6.28) });
    }
}

function updateAnimals(dt) {
    for (const a of animals) {
        if (a.hp <= 0) continue;
        const t = ANIMAL_TYPES[a.type]; a.animT += dt * 3;
        if (a.hitFlash > 0) a.hitFlash -= dt;
        if (a.stunTimer > 0) { a.stunTimer -= dt; continue; }
        if (a.attackCd > 0) a.attackCd -= dt;
        a.stateTimer -= dt;
        const dP = dist(a, player);
        const dm = (player.sprinting ? 1.4 : 1) * (isNight() ? 0.7 : 1);

        if (t.flees) {
            if (dP < t.detect * dm * 0.6) { a.state = 'flee'; const ang = angle(player, a); a.vx = Math.cos(ang) * t.speed * 1.2; a.vy = Math.sin(ang) * t.speed * 1.2; }
            else if (a.stateTimer <= 0) { a.state = Math.random() < 0.4 ? 'wander' : 'idle'; a.stateTimer = rand(2, 6); if (a.state === 'wander') { a.dir = rand(0, 6.28); a.vx = Math.cos(a.dir) * t.speed * 0.4; a.vy = Math.sin(a.dir) * t.speed * 0.4; } else { a.vx = 0; a.vy = 0; } }
        } else {
            if (a.state === 'idle' || a.state === 'wander') {
                if (dP < t.detect * dm) { a.state = 'chase'; a.alerted = true; }
                else if (a.stateTimer <= 0) {
                    if (t.territorial && dist(a, { x: a.homeX, y: a.homeY }) > 200) { a.state = 'wander'; const ang = angle(a, { x: a.homeX, y: a.homeY }); a.vx = Math.cos(ang) * t.speed * 0.5; a.vy = Math.sin(ang) * t.speed * 0.5; }
                    else { a.state = Math.random() < 0.5 ? 'wander' : 'idle'; a.dir = rand(0, 6.28); a.vx = a.state === 'wander' ? Math.cos(a.dir) * t.speed * 0.4 : 0; a.vy = a.state === 'wander' ? Math.sin(a.dir) * t.speed * 0.4 : 0; }
                    a.stateTimer = rand(2, 5);
                }
            }
            if (a.state === 'chase') {
                const ang = angle(a, player); let spd = t.speed * (1 + level * 0.05);

                // Safety logic: Animals fear the lit campfire
                const fire = world.camp.fire;
                if (fire.lit && dist(player, fire) < 130) {
                    // Turn away or stop chasing
                    a.state = 'flee';
                    a.vx = -Math.cos(ang) * spd;
                    a.vy = -Math.sin(ang) * spd;
                    continue;
                }

                if (t.charges && dP < 120) spd *= 1.8;
                a.vx = Math.cos(ang) * spd; a.vy = Math.sin(ang) * spd; a.dir = ang;
                if (dP < 30 && a.attackCd <= 0 && player.invincible <= 0) {
                    player.hp -= t.damage; player.hitFlash = 0.3; player.invincible = 0.5; a.attackCd = 1.2;
                    player.deathCause = `Dödad av en ${t.emoji}`;
                    for (let i = 0; i < 4; i++) particles.push({ x: player.x, y: player.y, vx: rand(-2, 2), vy: rand(-2, 2), life: 0.4, color: '#cc2222', r: 3 });
                }
                if (dP > t.detect * 2) { a.state = 'idle'; a.alerted = false; a.stateTimer = rand(2, 5); a.vx = 0; a.vy = 0; }
            }
            if (t.hidden && !a.revealed && dP < 60) { a.revealed = true; a.state = 'chase'; addMsg('⚠️ En orm! Akta dig!'); }
        }
        let nx = a.x + a.vx, ny = a.y + a.vy;
        nx = clamp(nx, 20, WORLD_W * TILE - 20); ny = clamp(ny, 20, WORLD_H * TILE - 20);
        if (world.camp.fire.lit && dist({ x: nx, y: ny }, world.camp.fire) < 80) { const fl = angle(world.camp.fire, a); nx = a.x + Math.cos(fl) * 2; ny = a.y + Math.sin(fl) * 2; }
        a.x = nx; a.y = ny;
    }
    // Dead animals => drop raw meat
    for (let i = animals.length - 1; i >= 0; i--) {
        if (animals[i].hp <= 0) {
            const a = animals[i];
            if (!ANIMAL_TYPES[a.type].flees || a.type === 'deer') world.items.push({ x: a.x, y: a.y, type: 'rawmeat', bobT: 0 });
            for (let j = 0; j < 8; j++) particles.push({ x: a.x, y: a.y, vx: rand(-3, 3), vy: rand(-3, 3), life: 0.8, color: '#8b0000', r: rand(2, 5) });
            kills++; animals.splice(i, 1);
        }
    }
}

function updateParticles(dt) { for (let i = particles.length - 1; i >= 0; i--) { const p = particles[i]; p.x += p.vx; p.y += p.vy; p.life -= dt; p.vy += dt; if (p.life <= 0) particles.splice(i, 1); } }
function updateMessages(dt) { for (let i = messages.length - 1; i >= 0; i--) { messages[i].t -= dt; if (messages[i].t <= 0) messages.splice(i, 1); } }

function updateHUD() {
    const p = player, fire = world.camp.fire;
    document.getElementById('bar-health').style.width = Math.max(0, p.hp) + '%';
    document.getElementById('bar-hunger').style.width = Math.max(0, p.hunger) + '%';
    document.getElementById('bar-warmth').style.width = Math.max(0, p.warmth) + '%';
    document.getElementById('bar-stamina').style.width = Math.max(0, p.stamina) + '%';
    document.getElementById('val-health').textContent = Math.round(Math.max(0, p.hp));
    document.getElementById('val-hunger').textContent = Math.round(Math.max(0, p.hunger));
    document.getElementById('val-warmth').textContent = Math.round(Math.max(0, p.warmth));
    document.getElementById('val-stamina').textContent = Math.round(Math.max(0, p.stamina));

    const hour = Math.floor(dayTime * 24) % 24, min = Math.floor((dayTime * 24 - Math.floor(dayTime * 24)) * 60);
    const day = Math.floor(survivalTime / DAY_LENGTH) + 1;
    document.getElementById('time-display').textContent = `${isNight() ? '🌙' : '☀️'} Dag ${day} — ${String(hour).padStart(2, '0')}:${String(min).padStart(2, '0')}`;
    document.getElementById('score-display').textContent = `⏱️ ${Math.floor(survivalTime)}s`;
    document.getElementById('level-display').textContent = `📈 Nivå ${level}/${MAX_LEVEL}`;

    const firePct = Math.round(fire.fuel / fire.maxFuel * 100);
    const fireIcon = fire.lit ? (firePct < 25 ? '🔥⚠️' : '🔥') : '❄️';
    document.getElementById('fire-display').textContent = `${fireIcon} Eld: ${firePct}%`;

    // Inventory
    const inv = document.getElementById('inventory'); inv.innerHTML = '';
    for (let i = 0; i < 6; i++) {
        const slot = document.createElement('div');
        slot.className = 'inv-slot' + (i === player.selectedSlot ? ' active' : '');
        const s = player.inventory[i];
        slot.innerHTML = `<span class="slot-key">${i + 1}</span>${s ? ITEMS[s.type].emoji : ''}${s ? `<span class="slot-count">${s.count}</span>` : ''}`;
        inv.appendChild(slot);
    }

    const ml = document.getElementById('message-log');
    ml.textContent = messages.length ? messages[messages.length - 1].txt : '';

    // Warnings
    if (p.warmth < 30 && !fire.lit) ml.textContent = '❄️ Du fryser! Samla ved och tänd elden!';
    else if (fire.fuel < 20 && fire.lit) ml.textContent = '⚠️ Elden håller på att slockna! Lägg i ved!';
    else if (hasItem('rawmeat') && fire.lit && dist(p, fire) < 80) ml.textContent = '[L] (Håll in 10s) Laga kött';
    else if (hasItem('stick') && dist(p, fire) < 80) ml.textContent = fire.lit ? '[0] Lägg ved i elden' : '[0] Tänd elden';
    else if (hasItem('stick', 3) && hasItem('stone', 2)) ml.textContent = '[C] Tillverka spjut (3🪵+2🪨)';
    else if (hasItem('stick', 2) && hasItem('stone', 1)) ml.textContent = '[C] Tillverka yxa (2🪵+1🪨)';
}

function gameOver(cause) {
    state = 'gameover';
    const time = Math.floor(survivalTime);
    if (time > highScore) { highScore = time; localStorage.setItem('forestHS', String(time)); }
    $hud.classList.add('hidden'); $over.classList.remove('hidden');
    document.getElementById('death-cause').textContent = cause;
    document.getElementById('survival-time').textContent = `Överlevde i ${time} sekunder`;
    document.getElementById('death-level').textContent = `Nådde nivå ${level}/${MAX_LEVEL}`;
    document.getElementById('kills-count').textContent = `Dödade ${kills} djur`;
    document.getElementById('high-score-display').textContent = `Rekord: ${highScore}s`;
}

// ============================================
// 3D RENDER
// ============================================
const meshes = new Map(); // Store meshes by object reference

function getMesh(obj, createFn) {
    if (!meshes.has(obj)) {
        const mesh = createFn();
        scene.add(mesh);
        meshes.set(obj, mesh);
    }
    return meshes.get(obj);
}

function update3D() {
    // Player
    if (player) {
        const pMesh = getMesh(player, () => {
            const m = new THREE.Group();
            const body = new THREE.Mesh(geometries.cylinder, materials.player);
            body.position.y = 10;
            body.scale.set(6, 12, 6);
            body.castShadow = true;
            m.add(body);
            return m;
        });
        pMesh.position.set(player.x, 0, player.y);
        pMesh.rotation.y = -player.dir;

        // Attack animation visual tilt
        if (player.attackAnim > 0) pMesh.rotation.x = 0.5;
        else pMesh.rotation.x = 0;

        // Camera follow
        camera3d.position.x = player.x;
        camera3d.position.z = player.y + 150;
        camera3d.position.y = 150;
        camera3d.lookAt(player.x, 0, player.y);
    }

    // Trees
    for (const t of world.trees) {
        getMesh(t, () => {
            const m = new THREE.Group();
            const trunkMat = t.type === 'birch' ? materials.treeTrunkBirch : materials.treeTrunkPine;
            const leavesMat = t.type === 'pine' ? materials.treeLeavesPine : materials.treeLeavesOak;
            const trunk = new THREE.Mesh(geometries.cylinder, trunkMat);
            trunk.scale.set(t.r * 0.3, t.h * 30, t.r * 0.3);
            trunk.position.y = t.h * 15;
            trunk.castShadow = true;
            m.add(trunk);
            const leaves = new THREE.Mesh(t.type === 'pine' ? geometries.cone : geometries.dodecahedron, leavesMat);
            leaves.scale.set(t.r * 1.5, t.h * 40, t.r * 1.5);
            leaves.position.y = t.h * 30 + 10;
            leaves.castShadow = true;
            m.add(leaves);
            m.position.set(t.x, 0, t.y);
            return m;
        });
    }

    // Rocks
    for (const r of world.rocks) {
        getMesh(r, () => {
            const m = new THREE.Mesh(geometries.dodecahedron, materials.rock);
            m.scale.set(r.r, r.r, r.r);
            m.position.set(r.x, r.r * 0.5, r.y);
            m.rotation.set(rand(0, 3), rand(0, 3), rand(0, 3));
            m.castShadow = true;
            return m;
        });
    }

    // Bushes
    for (const b of world.bushes) {
        const mesh = getMesh(b, () => {
            const m = new THREE.Mesh(geometries.sphere, materials.bush);
            m.scale.set(b.r, b.r * 0.8, b.r);
            m.position.set(b.x, b.r * 0.5, b.y);
            m.castShadow = true;
            return m;
        });
        if (b.picked) mesh.scale.y = b.r * 0.5;
    }

    // Chests
    for (const ch of world.chests) {
        const mesh = getMesh(ch, () => {
            const m = new THREE.Mesh(geometries.box, materials.chest);
            m.scale.set(20, 15, 15);
            m.position.set(ch.x, 7.5, ch.y);
            m.castShadow = true;
            return m;
        });
        if (ch.opened) {
            mesh.rotation.x = Math.PI / 4;
        }
    }

    // Items
    for (const it of world.items) {
        const mesh = getMesh(it, () => {
            const mat = it.type === 'stick' ? materials.stick : (it.type === 'rawmeat' ? materials.rawmeat : materials.stoneItem);
            const r = it.type === 'stick' ? 6 : 4;
            const geo = it.type === 'stick' ? geometries.cylinder : geometries.dodecahedron;
            const m = new THREE.Mesh(geo, mat);
            m.scale.set(r, r, r);
            if (it.type === 'stick') { m.rotation.z = Math.PI / 2; m.scale.set(2, 10, 2); }
            m.castShadow = true;
            return m;
        });
        mesh.position.set(it.x, 3 + Math.sin(gameTime * 2 + it.bobT) * 2, it.y);
    }

    // Animals
    for (const a of animals) {
        if (a.hp <= 0) continue;
        const aMesh = getMesh(a, () => {
            const m = new THREE.Mesh(geometries.box, new THREE.MeshLambertMaterial({ color: ANIMAL_TYPES[a.type].color }));
            const size = a.type === 'bear' ? 14 : (a.type === 'snake' ? 6 : 10);
            m.scale.set(size * 1.5, size * 1.5, size * 2.5);
            m.castShadow = true;
            return m;
        });
        aMesh.position.set(a.x, 6 + Math.sin(a.animT) * 2, a.y);
        aMesh.rotation.y = -a.dir;

        // hit flash
        if (a.hitFlash > 0) aMesh.material.emissive.setHex(0x550000);
        else aMesh.material.emissive.setHex(0x000000);
    }

    // Camp Fire
    if (world.camp) {
        const fire = world.camp.fire;
        const fMesh = getMesh(fire, () => {
            const m = new THREE.Group();
            const base = new THREE.Mesh(geometries.cylinder, materials.fireStone);
            base.scale.set(15, 2, 15);
            m.add(base);
            return m;
        });
        fMesh.position.set(fire.x, 1, fire.y);
        fireLight.position.set(fire.x, 20, fire.y);
        fireLight.intensity = fire.lit ? (0.5 + fire.fuel / fire.maxFuel) : 0;

        const tentMesh = getMesh(world.camp.tent, () => {
            const m = new THREE.Mesh(geometries.cone, materials.tent);
            m.scale.set(35, 40, 35);
            m.castShadow = true;
            return m;
        });
        tentMesh.position.set(world.camp.tent.x, 20, world.camp.tent.y);
        tentMesh.rotation.z = -0.2; // broken tilt
    }

    // Particles
    const activeParticles = new Set(particles);
    for (const p of particles) {
        const mesh = getMesh(p, () => {
            const m = new THREE.Mesh(geometries.box, new THREE.MeshBasicMaterial({ color: p.color }));
            m.scale.set(p.r, p.r, p.r);
            return m;
        });
        // p.y is stored from 2D logic which assumed top-down (so p.y meant forward-backward). 
        // We've translated 2D y to 3D z. If particle has vy, it moves along 3D z. 
        // We'll give it an arbitrary 3D y based on its life to 'fall'
        mesh.position.set(p.x, p.life * 20, p.y);
    }

    // Dynamic Cleanup of missing logical objects
    for (const [obj, mesh] of meshes.entries()) {
        const isActive =
            obj === player ||
            (obj === world.camp?.fire) ||
            (obj === world.camp?.tent) ||
            world.items.includes(obj) ||
            animals.includes(obj) ||
            world.chests.includes(obj) ||
            world.trees.includes(obj) ||
            world.rocks.includes(obj) ||
            world.bushes.includes(obj) ||
            activeParticles.has(obj);

        if (!isActive) {
            scene.remove(mesh);
            meshes.delete(obj);
        }
    }

    // Day/Night ambient light
    const darkness = getDarkness();
    ambientLight.intensity = Math.max(0.1, 0.8 - darkness * 0.7);
    scene.background.setHex(lerpColor(0x0d200d, 0x020502, darkness));
    scene.fog.color.setHex(lerpColor(0x0d200d, 0x020502, darkness));
}

function lerpColor(a, b, t) {
    const ar = (a >> 16) & 0xff, ag = (a >> 8) & 0xff, ab = a & 0xff;
    const br = (b >> 16) & 0xff, bg = (b >> 8) & 0xff, bb = b & 0xff;
    return ((ar + (br - ar) * t) << 16) | ((ag + (bg - ag) * t) << 8) | (ab + (bb - ab) * t);
}

function render() {
    if (state === 'menu') {
        renderer.render(scene, camera3d);
        return;
    }
    update3D();
    renderer.render(scene, camera3d);
}

// --- GAME LOOP ---
function loop(ts) {
    const dt = Math.min((ts - lastTime) / 1000, 0.05);
    lastTime = ts;
    if (state === 'playing') update(dt);
    render();
    requestAnimationFrame(loop);
}
requestAnimationFrame(ts => { lastTime = ts; loop(ts); });
